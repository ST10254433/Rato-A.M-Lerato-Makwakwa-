package com.example.masterbudget;

public interface OnItemsCLick {
    void onClick(ExpenseModel expenseModel);
}