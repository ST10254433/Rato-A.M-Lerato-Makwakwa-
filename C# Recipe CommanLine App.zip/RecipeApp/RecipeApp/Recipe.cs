﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApp
{
    internal class Recipe
    {
        // Public properties for the recipe's name, list of ingredients, and list of steps
        public string Name { get; set; } // The name of the recipe
        public Ingredient[] Ingredients { get; set; } // Array of ingredients in the recipe
        public string[] Steps { get; set; } // Array of steps (instructions) in the recipe

        // Constructor to initialize a Recipe object with specified name, ingredients, and steps
        public Recipe(string name, Ingredient[] ingredients, string[] steps)
        {
            Name = name; // Assigning the provided name to the Name property
            Ingredients = ingredients; // Assigning the provided ingredients to the Ingredients property
            Steps = steps; // Assigning the provided steps to the Steps property
        }

        // Constructor to initialize a Recipe object with specified number of ingredients and steps
        public Recipe(int numIngredients, int numSteps)
        {
            // Create arrays for ingredients and steps with the specified sizes
            Ingredients = new Ingredient[numIngredients];
            Steps = new string[numSteps];
        }

        // Method to add an ingredient to the recipe at the specified index
        public void AddIngredient(int index, Ingredient ingredient)
        {
            Ingredients[index] = ingredient;
        }

        // Method to add a step (instruction) to the recipe at the specified index
        public void AddStep(int index, string step)
        {
            Steps[index] = step;
        }

        // Method to reset quantities of all ingredients to their original values
        public void ResetQuantities()
        {
            // Assuming the Ingredient class keeps track of original quantities
            // This method would reset the quantities of all ingredients to their original values
            // Implementation should be added based on the specific requirements
        }

        // Method to scale the recipe's ingredient quantities by a specified factor
        public void ScaleRecipe(double factor)
        {
            // Iterate over each ingredient in the recipe
            foreach (var ingredient in Ingredients)
            {
                // Scale the quantity of the ingredient by the provided factor
                ingredient.Quantity *= factor;
            }
        }
    }
}
