﻿using System.Numerics;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace RecipeApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Initialize a new User object
            User user = new User();
            Steps[] stepsArray;

            // Prompt for user details and capture them
            Console.WriteLine("Enter User Details:");
            Console.Write("Name: ");
            user.Name = Console.ReadLine(); // Get the user's first name
            Console.Write("Surname: ");
            user.Surname = Console.ReadLine(); // Get the user's surname

            // Flag to control the main recipe loop
            bool EnterRecipe = true;

            // Main loop for entering recipe details
            while (EnterRecipe)
            {
                Console.WriteLine("\nEnter Recipe Details:");

                // Flag to control the ingredients input loop
                bool enterIngredients = true;
                Ingredient[] ingredientsArray = null;

                // Loop for entering ingredients
                while (enterIngredients)
                {
                    Console.Write("Number of Ingredients: ");
                    int numIngredients = Convert.ToInt32(Console.ReadLine());
                    ingredientsArray = new Ingredient[numIngredients]; // Create array for ingredients

                    // Loop to capture details for each ingredient
                    for (int i = 0; i < numIngredients; i++)
                    {
                        Console.WriteLine($"Enter details for Ingredient {i + 1}:");
                        Console.Write("Name: ");
                        string name = Console.ReadLine(); // Get ingredient name
                        Console.Write("Quantity: ");
                        double quantity = Convert.ToDouble(Console.ReadLine()); // Get ingredient quantity
                        Console.Write("Unit of Measurement: ");
                        string unit = Console.ReadLine(); // Get unit of measurement

                        // Create an Ingredient object and add it to the array
                        ingredientsArray[i] = new Ingredient(name, quantity, unit);
                    }

                    // Prompt for the number of steps
                    Console.Write("\nNumber of Steps: ");
                    int numSteps = Convert.ToInt32(Console.ReadLine());
                    stepsArray = new Steps[numSteps]; // Create array for steps

                    // Loop to capture details for each step
                    for (int i = 0; i < numSteps; i++)
                    {
                        Console.WriteLine($"Enter description for Step {i + 1}:");
                        string description = Console.ReadLine(); // Get step description

                        // Create a Steps object and add it to the array
                        stepsArray[i] = new Steps(i + 1, description);
                    }

                    // Create a Recipe object and add ingredients and steps
                    Recipe recipe = new Recipe(numIngredients, numSteps);

                    // Add ingredients to the recipe
                    for (int i = 0; i < numIngredients; i++)
                    {
                        recipe.AddIngredient(i, ingredientsArray[i]);
                    }

                    // Add steps to the recipe
                    for (int i = 0; i < numSteps; i++)
                    {
                        recipe.AddStep(i, stepsArray[i].Description);
                    }

                    // Prompt to see if the user wants to scale the recipe
                    Console.Write("Do you want to scale the recipe? (y/n): ");
                    char choice = Console.ReadLine().ToLower()[0];
                    if (choice == 'y')
                    {
                        // If the user wants to scale the recipe, prompt for scaling factor
                        Console.Write("Enter scaling factor: ");
                        double scalingFactor = Convert.ToDouble(Console.ReadLine());
                        recipe.ScaleRecipe(scalingFactor); // Scale the recipe
                        Console.WriteLine("Recipe scaled successfully.");
                    }

                    // Display the recipe details
                    Console.WriteLine("\nRecipe Details:");
                    Console.WriteLine($"User: {user.Name} {user.Surname}."); // Display the user's name and surname
                    Console.WriteLine("\nIngredients:");
                    foreach (Ingredient ingredient in recipe.Ingredients)
                    {
                        Console.WriteLine($"Ingredient Name: {ingredient.Name}");
                        Console.WriteLine($"Quantity: {ingredient.Quantity}");
                        Console.WriteLine($"Unit of Measurement: {ingredient.Unit}");
                    }
                    Console.WriteLine("\nSteps:");
                    foreach (string step in recipe.Steps)
                    {
                        Console.WriteLine(step, numSteps); // Display the steps
                    }

                    // Menu for optional quantity reset & other options
                    Console.WriteLine("\nOptions:");
                    Console.WriteLine("1. Reset quantities to original values");
                    Console.WriteLine("2. Clear all data to enter a new recipe");
                    Console.WriteLine("3. Enter another recipe");
                    Console.WriteLine("4. Exit");

                    Console.Write("Enter your choice: ");
                    int choiceNumber = Convert.ToInt32(Console.ReadLine());

                    // Handle the user's choice
                    switch (choiceNumber)
                    {
                        case 1:
                            // Reset the recipe quantities to their original values
                            recipe.ResetQuantities();
                            Console.WriteLine("Quantities reset to original values.");
                            break;
                        case 2:
                            // Clear all data to enter a new recipe
                            user.Name = "";
                            user.Surname = "";
                            ingredientsArray = null;
                            stepsArray = null;
                            Console.WriteLine("All data cleared.");
                            break;
                        case 3:
                            break; // Continue to enter another recipe
                        case 4:
                            // Exit the loop
                            EnterRecipe = false;
                            break;
                        default:
                            Console.WriteLine("Invalid choice! Please try again.");
                            break;
                    }

                    // Break the loop if the user chooses to enter another recipe or exit
                    if (choiceNumber == 3 || choiceNumber == 4)
                    {
                        break;
                    }
                }
            }

        }
    }
}
    

    

